function checkHex(val)
{
    var i=0;

    for(i=0; i<val.length; i++)
    {
        if (!((val.charAt(i)>='0' && val.charAt(i)<='9') ||
            (val.charAt(i)>='A' && val.charAt(i)<='F') ||
            (val.charAt(i)>='a' && val.charAt(i)<='f')))
        {
            alert('Invalid number '+val.charAt(i)+' at position '+ (i+1)+'! Must be 0123456789abcdefABCDEF');
            return false;
        }
    }
    return true;
}
var ASCIIStrValid = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' + 'abcdefghijklmnopqrstuvwxyz' + '0123456789' +
    '!#$&()*+,-./%.:;<=>?@[]^_{|}~\"' + '\\' + "\'" + " ";
function checkASC(keyval,place)
{
    var j, k, flag;
    for ( k=0; k<keyval.length; k++ ) {
        for(j=0;j<ASCIIStrValid.length;j++) {
            flag = false;
            if(keyval.charAt(k) ==  ASCIIStrValid.charAt(j)) {
                flag = true;
                break;
            }
        }
        if(flag == false) {
            if(place=="ssid")
            {
                ShowError(document.getElementById("ssid"),"This character is not accepted." );
            }
            else if(place=="passphrase")
            {
                ShowError(document.getElementById("passphrase"),"This character is not accepted." );
            }
            return false;
        }
    }

    flag = false;
    for ( k=0; k<keyval.length; k++ )
    {
        if(keyval.charAt(k) != ' ')
        {
            flag = true;
            break;
        }
    }
    if(flag == false)
    {
        if(place=="ssid")
        {
            ShowError(document.getElementById("ssid"),"Invalid string: can not be empty!");
        }
        else if(place=="passphrase")
        {
            ShowError(document.getElementById("passphrase"),"Invalid string: can not be empty!");
        }
        return false;
    }

    return true;
}

function checkinvalidkey(keyval)
{
    var k;
    var val;
    for ( k=0; k<keyval.length; k++ )
    {
        val = keyval.charAt(k);
        if( val == "\'" || val == "\"" || val == "\\" || val == "\<" || val == "\>" || val == ";"
            || val == "," || val == ":" || val == "\&" || val == "\*" || val =="\[" || val =="\]" || val =="$" || val ==" ")
        {
            return false;
        }
    }
    return true;
}


function ssid_check_blank(keyval)
{
    if (keyval)
    {
        if ( keyval.charAt(0) == " "
            || keyval.charAt(keyval.length-1) == " " )
        {
            return false;
        }
    }
    return true;
}

function checkSameLine(str)
{
    var len = str.length;
    for (var i=0; i<str.length; i++)
    {
        if ( str.charAt(i) == '\r' || str.charAt(i) == '\n')
        {
            return false;
        }
        else
        {
            continue;
        }
    }
    return true;
}

function security_check_blank(keyval)
{
    if (keyval)
    {
        if ( keyval.charAt(keyval.length-1) == " " )
        {
            return false;
        }
    }
    return true;
}

function checkAPNParam(keyval)
{
    var i = 0;
    if(keyval.length > 100){
        return false;
    }
    if(keyval.charAt(0) == '.'||keyval.charAt(0) == '-' || keyval.charAt(keyval.length-1) == '.' || keyval.charAt(keyval.length-1) == '-'){
        return false;
    }
    for (i=0; i<keyval.length; i++){
        if (!((keyval.charAt(i)>='0' && keyval.charAt(i)<='9')
            ||(keyval.charAt(i)>='A' && keyval.charAt(i)<='Z')
            ||(keyval.charAt(i)>='a' && keyval.charAt(i)<='z')
            || keyval.charAt(i)=='.'|| keyval.charAt(i)=='-')){
            return false;
        }
    }
    return true;
}

function combinIP(d1,d2,d3,d4)
{
    var ip=d1.value+"."+d2.value+"."+d3.value+"."+d4.value;
    if (ip=="...")
        ip="";
    return ip;
}

function combinMAC(m1,m2,m3,m4,m5,m6)
{
    var mac=m1.value+":"+m2.value+":"+m3.value+":"+m4.value+":"+m5.value+":"+m6.value;
    if (mac==":::::")
        mac="";
    return mac;
}

function decomMAC2(ma,macs,nodef)
{
    var re = /^[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}:[0-9a-fA-F]{1,2}$/;
    if (re.test(macs)||macs=='')
    {
		if (ma.length!=6)
		{
			ma.value=macs;
			return true;
		}
	if (macs!='')
        	var d=macs.split(":");
	else
		var d=['','','','','',''];
        for (i = 0; i < 6; i++)
		{
            ma[i].value=d[i];
			if (!nodef) ma[i].defaultValue=d[i];
		}
        return true;
    }
    return false;
}

function decomIP2(ipa,ips,nodef)
{
    var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    if (re.test(ips))
    {
        var d =  ips.split(".");
        for (i = 0; i < 4; i++)
		{
            ipa[i].value=d[i];
			if (!nodef) ipa[i].defaultValue=d[i];
		}
        return true;
    }
    return false;
}

function combinIP2(d)
{
	if (d.length!=4) return d.value;
    var ip=d[0].value+"."+d[1].value+"."+d[2].value+"."+d[3].value;
    if (ip=="...")
        ip="";
    return ip;
}
function combinMAC2(m)
{
    var mac=m[0].value+":"+m[1].value+":"+m[2].value+":"+m[3].value+":"+m[4].value+":"+m[5].value;
	mac=mac.toUpperCase();
    if (mac==":::::")
        mac="";
    return mac;
}

function Cfg(i,n,v)
{
	this.i=i;
    this.n=n;
    this.v=this.o=v;
}

var CA = new Array() ;

function addCfg(n,i,v)
{
	CA.length++;
    CA[CA.length-1]= new Cfg(i,n,v);
 //  alert(CA);
}

function idxOfCfg(kk)
{
    if (kk=='undefined') { alert("undefined"); return -1; }
    for (var i=0; i< CA.length ;i++)
    {

        if ( CA[i].n != 'undefined' && CA[i].n==kk )
            return i;
    }
    return -1;
}

function getCfg(n)
{
	var idx=idxOfCfg(n)
	if ( idx >=0)
		return CA[idx].v ;
	else
		return "";
}

function setCfg(n,v)
{
	var idx=idxOfCfg(n)
	if ( idx >=0)
	{
		//debug, 
	if (CA[idx].v != v) //alert("setCfg("+n+","+v+")");
		CA[idx].v = v ;
	}
}

function cfg2Form(f)
{
    for (var i=0;i<CA.length;i++)
    {
        var e=eval('f.'+CA[i].n);
        if ( e )
		{
			if (e.name=='undefined') continue;
			if ( e.length && e[0].type=='text' )
			{
				if (e.length==4) decomIP2(e,CA[i].v);
				else if (e.length==6) decomMAC2(e,CA[i].v);
			}
			else if ( e.length && e[0].type=='radio')
			{
				for (var j=0;j<e.length;j++)
					e[j].checked=e[j].defaultChecked=(e[j].value==CA[i].v);
			}
			else if (e.type=='checkbox')
				e.checked=e.defaultChecked=Number(CA[i].v);
			else if (e.type=='select-one')
			{
				for (var j=0;j<e.options.length;j++)
					 if(e.options[j].value==CA[i].v) {
						e.selectedIndex = j;
						}
			}
			else
				e.value=getCfg(e.name);
			if (e.defaultValue!='undefined')
				e.defaultValue=e.value;
		}
    }
}

var frmExtraElm='';
function form2Cfg(f)
{

    for (var i=0;i<CA.length;i++)
    {
        var e=eval('f.'+CA[i].n);
		if ( e )
		{
			if (e.disabled) continue;
			if ( e.length && e[0].type=='text' )
			{
				if (e.length==4) CA[i].v=combinIP2(e);
				else if (e.length==6) CA[i].v=combinMAC2(e);
			}
			else if ( e.length && e[0].type=='radio')
			{
				for (var j=0;j<e.length;j++)
					if (e[j].checked) { CA[i].v=e[j].value; break; }
			}
			else
			if (e.type=='checkbox')
				setCfg(e.name, Number(e.checked) );
			else
				setCfg(e.name, e.value);
		}
    }
}

var OUTF;
function frmHead(na,to,cmd,go)
{
	OUTF="<FORM name="+na+" action="+to+" method=POST>\n"+
	"<INPUT type=hidden name=CMD value="+cmd+">\n"+
	"<INPUT type=hidden name=GO value="+go+">\n";
}

function frmEnd()
{
	OUTF+="</FORM>\n";
}

function frmAdd(n,v)
{
	set1="<input type=hidden name="+n+" value=\"";
	v=v.replace(/\"/g,"&quot;");
	var r=new RegExp(set1+".*\n","g");
	if (OUTF.search(r) >= 0)
		OUTF=OUTF.replace(r,(set1+v+"\">\n"));
	else
		OUTF += (set1+v+"\">\n");
}

function genForm(n,a,d,g)
{
	frmHead(n,a,d,g);
	var sub=0;
    for (var i=0;i<CA.length;i++)
	{
		if (CA[i].v!=CA[i].o)
		{
			frmAdd("SET"+sub,String(CA[i].i)+"="+CA[i].v);
			sub++;
		}
	}
	if (frmExtraElm.length)
		OUTF+=frmExtraElm;
	frmExtraElm=''; //reset
	frmEnd();
	return OUTF;
}

function subForm(f1,a,d,g)
{
	var msg=genForm('OUT',a,d,g);
/*DEMO*/
	if (!confirm(msg)) return;
/*END_DEMO*/

	var newElem = document.createElement("div");
	newElem.innerHTML = msg ;
	f1.parentNode.appendChild(newElem);
	f=document.OUT;
	f.submit();
}

function getStyle(objId) {
	var obj=document.getElementById(objId);	
	if (obj) return obj.style;
	else return 0;
}

function setStyle(id, v) {
    var st = getStyle(id);
    if(st) { st.display = v; return true; } else return false;
} 

