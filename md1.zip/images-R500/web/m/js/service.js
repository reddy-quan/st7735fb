﻿function service() {
    /**
     * Service
     * @module service
     * @class service
     */
	var wifiCallbackDestination = window;
	var unknownErrorObject = {
		errorType : 'UnknownError',
		errorId : '123',
		errorText : 'UnknownError'
	};
    
	var isTest = false;
    if (isTest) {
		$("#buttom-bubble").hide();
	}
   
	/**
	 * Ajax同步调用
	 * @method syncRequest
	 * @param {Object} params json参数对象
	 * @param {Boolean} isPost 是否为post方法
	 */
	function syncRequest(params, isPost) {
		return ajaxRequest(params, null, null, false, isPost);
	}

	/**
	 * Ajax异步调用
	 * @method asyncRequest
	 * @param {Object} params json参数对象
	 * @param {Function} successCallback 成功回调函数
	 * @param {Function} errorCallback 失败回调函数
	 * @param {Boolean} isPost 是否为post方法
	 */
	function asyncRequest(params, successCallback, errorCallback, isPost) {
		ajaxRequest(params, successCallback, errorCallback, true, isPost);
	}

	/**
	 * Ajax异步调用
	 * @method ajaxRequest
	 * @param {Object} params json参数对象
	 * @param {Function} successCallback 成功回调函数
	 * @param {Function} errorCallback 失败回调函数
	 * @param {Boolean} async 是否为异步方法
	 * @param {Boolean} isPost 是否为post方法
	 */
	function ajaxRequest(params, successCallback, errorCallback, async, isPost) {
		var result = null;
		if(params.isTest){
				result = simulate.simulateRequest(params, successCallback, errorCallback, async, isPost);
				if (async) {
					setTimeout(function() {successCallback(result);}, getRandomInt(120) + 50);
					//successCallback(result)
					return;
				}else{
					return result;
				}
		}
		$.ajax({
			type : !!isPost ? "POST" : "GET",
			url : isPost ? "/goform/set_process" : params.params ? "/goform/get_process"
					: "/goform/set_process",
			data : params,
			dataType : "json",
			async : !!async,
			cache : false,
			error : function(data) {
				if (async) {
					errorCallback(data);
				} else if(data.status == 200) {
					result = jQuery.parseJSON('(' + data.responseText + ')');
				}
			},
			success : function(data) {
				if (async) {
					successCallback(data);
				} else {
					result = data;
				}
			}
		});
		if (!async) {
			return result;
		}
	}

	/**
	 * doStuff业务处理函数
	 * @method doStuff
	 * @param {Object} params json参数对象
	 * @param {Object} result 错误对象
	 * @param {Function} prepare 数据准备函数
	 * @param {Function} dealMethod 结果适配函数
	 * @param {Object} errorObject 默认错误对象
	 * @param {Boolean} isPost 是否为post方法
	 */
	function doStuff(args, result, prepare, dealMethod, errorObject, isPost) {
		var params = args[0], callback = args[1], errorCallback = args[2];
		var objectToReturn;

		if (result && typeof result.errorType === 'string') {
			objectToReturn = $.extend(unknownErrorObject, result);

			if (!callback) {
				// sleep(DelayOnEachCallMillis);
				return objectToReturn;
			}
			doCallback(objectToReturn, callback, errorCallback);
		} else {
			objectToReturn = $.extend({}, result); // Duplicate it.

			var requestParams;
			if (prepare) {
				requestParams = prepare(params, isPost);
			} else {
				requestParams = params;
			}
			if (!callback) {
				if (requestParams && (requestParams.params || requestParams.goformID)) {
					var r = syncRequest(requestParams, isPost);
					if (dealMethod) {
						objectToReturn = $.extend({}, dealMethod(r));
					}else{
                        objectToReturn = r;
                    }
				}
				// sleep(DelayOnEachCallMillis);
				return objectToReturn;
			} else {
				if (requestParams && (requestParams.params || requestParams.goformID)) {
					asyncRequest(requestParams, function(data) {
						if (dealMethod) {
							objectToReturn = $.extend({}, dealMethod(data));
						} else {
							objectToReturn = $.extend({}, data);
						}
						//手动处理callback
						if(!requestParams.notCallback){
							doCallback(objectToReturn, callback, errorCallback);
						}
					}, function() {
						if (errorObject) {
							objectToReturn = $.extend(unknownErrorObject, errorObject);
						} else {
							objectToReturn = $.extend(unknownErrorObject, {
								errorType : 'Unknown'
							});
						}
						doCallback(objectToReturn, callback, errorCallback);
					}, isPost);
				} else {
					doCallback(objectToReturn, callback, errorCallback);
				}
			}
		}
		function doCallback(resultToReturn, callback, errorCallback) {
			errorCallback = errorCallback ? errorCallback : callback;
			if (isErrorObject(resultToReturn)) {
				switch (resultToReturn.errorType) {
				case 'cellularNetworkError':
				case 'deviceError':
				case 'wifiConnectionError':
					wifiCallbackDestination.receivedNonSpecificError(resultToReturn);
					break;
				default:
					errorCallback(resultToReturn);
				}
			} else {
				callback(resultToReturn);
			}
		}
	}
	function isErrorObject(object) {
        return typeof object.errorType === 'string';
    }

	
	/**
     * 获取SD Card配置信息
     * @method getSDConfiguration
     */
    function getSDConfiguration(){
    	return doStuff(arguments, {}, prepare, deal, null, false);

        function prepare(params, isPost) {
            var requestParams = {
	            isTest : isTest,
	            params : "sdcard_mode_option,sd_card_state,HTTP_SHARE_STATUS,HTTP_SHARE_CARD_USER,HTTP_SHARE_WR_AUTH,HTTP_SHARE_FILE",
	            multi: 1
            };
            return requestParams;
        }

        function deal(data) {
            if (data) {
            	var fileToShare;
            	if("mmc2" == data.HTTP_SHARE_FILE || "/mmc2" == data.HTTP_SHARE_FILE || "/mmc2/" == data.HTTP_SHARE_FILE){
            		fileToShare = "1";
            	} else {
            		fileToShare = "0";
            	}
            	var result = {
        			sd_mode: data.sdcard_mode_option == "1" ? "0" : "1",
        			sd_status: data.sd_card_state,
        			share_status: data.HTTP_SHARE_STATUS == "Enabled" ? "1" : "0",
        			share_user: data.HTTP_SHARE_CARD_USER,
        			share_auth: data.HTTP_SHARE_WR_AUTH == "readWrite" ? "1" : "0",
        			file_to_share: fileToShare,
        			share_file: data.HTTP_SHARE_FILE
            	};
                return result;
            } else {
                return unknownErrorObject;
            }
        }
    }
    /**
     * 设置SD Card Mode
     * @method setSdCardMode
     */
    function setSdCardMode(){
    	return doStuff(arguments, {}, prepare, deal, null, true);

        function prepare(params, isPost) {
            var requestParams = {
	            isTest : isTest,
	            goformID : "HTTPSHARE_MODE_SET",
	            mode_set: params.mode == "0" ? "http_share_mode" : "usb_mode"
            };
            return requestParams;
        }

        function deal(data) {
			if (data && data.result == 'success') {
				return {result: true};
			} else {
				return {result: false};
			}
		}
    }

    /**
     * 检查文件是否存在
     * @method checkFileExists
     */
    function checkFileExists(){
    	return doStuff(arguments, {}, prepare, deal, null, true);

        function prepare(params, isPost) {
            var requestParams = {
	            isTest : isTest,
	            goformID : "GOFORM_HTTPSHARE_CHECK_FILE",
	            path_SD_CARD: params.path
            };
            return requestParams;
        }

        function deal(data) {
			if (data) {
				if (data.result == "no_sdcard") {
					return {
						status : "no_sdcard"
					};
				} else if (data.result == "noexist") {
					return {
						status : "noexist"
					};
				} else {
					return {
						status : "exist"
					};
				}
			} else {
				return unknownErrorObject;
			}
		}
    }

    /**
	 * 进入文件夹，并获取文件夹内文件列表
	 *
	 * @method getFileList
	 * @return {Object}
	 * @example
	 * 		{"result":{"totalRecord":"4", "fileInfo":[
	 *          {"fileName":"card","attribute":"document","size":"0","lastUpdateTime":"20120510"},
	 *          {"fileName":"cf","attribute":"document","size":"0","lastUpdateTime":"20120510"},
	 *          {"fileName":"net","attribute":"document","size":"0","lastUpdateTime":"20120510"},
	 *          {"fileName":"ram","attribute":"document","size":"0","lastUpdateTime":"20120510"}]}}
	 */
	function getFileList() {
		return doStuff(arguments, {}, prepare, deal, null, true);

		function prepare(params, isPost) {
			var requestParams = {
				isTest : isTest,
				goformID : "HTTPSHARE_ENTERFOLD",
				path_SD_CARD : params.path
			};
			return requestParams;
		}

		function deal(data) {
			if (data) {
				if (data.result == 'failure') {
					return $.extend(unknownErrorObject, {
						errorType : "get_file_list_failure"
					});
				} else if (data.result == "no_sdcard") {
					return $.extend(unknownErrorObject, {
						errorType : "no_sdcard"
					});
				} else {
					return parseSdCardFile(data.result);
				}
			} else {
				return unknownErrorObject;
			}
		}

		function parseSdCardFile(result) {
			var fileInfo = {};
			fileInfo.totalRecord = result.totalRecord;
			var fileArr = [];
			var details = result.fileInfo;
			for ( var i = 0; details && i < details.length; i++) {
				if(details[i].fileName == ""){
					continue;
				}
				var obj = {};
				obj.fileName = details[i].fileName;
				obj.attribute = details[i].attribute;
				obj.size = details[i].size;
				obj.lastUpdateTime = details[i].lastUpdateTime;
				fileArr.push(obj);
			}
			fileInfo.details = fileArr;
			return fileInfo;
		}
	}

    /**
     * sd card 文件重命名
     * @method fileRename
     * @return {Object}
     * @example
     * requestParams = {
			goformID : "HTTPSHARE_FILE_RENAME",
            path_SD_CARD : params.path,
			OLD_NAME_SD_CARD : oldpath,
			NEW_NAME_SD_CARD : newpath
		}
     */
    function fileRename(){
    	return doStuff(arguments, {}, prepare, deal, null, true);

        function prepare(params, isPost) {
            var d = new Date();
            var currentTime = d.getTime();
            var zoneOffsetSeconds = d.getTimezoneOffset() * 60;
            return {
                isTest: isTest,
                goformID: "HTTPSHARE_FILE_RENAME",
                path_SD_CARD: params.path,
                OLD_NAME_SD_CARD: params.oldPath,
                NEW_NAME_SD_CARD: params.newPath,
                path_SD_CARD_time: transUnixTime(currentTime),
                path_SD_CARD_time_unix: Math.round((currentTime - zoneOffsetSeconds * 1000) / 1e3)
            };
        }

        function deal(data) {
			if (data) {
				if (data.result == "success") {
					return {
						result : true
					};
				} else if (data.result == "no_sdcard") {
					return $.extend(unknownErrorObject, {
						errorType : "no_sdcard"
					});
				} else {
					return {
						result : false
					};
				}
			} else {
				return unknownErrorObject;
			}
		}
    }

    /**
     * 获取SD Card容量
     * @method getSdMemorySizes
     * @return {Object}
     * @example
     * {
			totalMemorySize : data.sd_card_total_size,
			availableMemorySize : data.sd_card_avi_space
		}
     */
    function getSdMemorySizes() {
		return doStuff(arguments, {}, prepare, deal, null, false);

		function prepare(params, isPost) {
			var requestParams = {
				isTest : isTest,
				params : "HTTPSHARE_GETCARD_VALUE"
			};
			return requestParams;
		}

		function deal(data) {
			if (!data || (data.result && data.result == "no_sdcard")) {
				return $.extend(unknownErrorObject, {
					errorType : "no_sdcard"
				});
			} else {
				return {
					totalMemorySize : data.sd_card_total_size == "" ? 0 : data.sd_card_total_size * 32 * 1024,
					availableMemorySize : data.sd_card_avi_space == "" ? 0 : data.sd_card_avi_space * 32 * 1024
				};
			}
		}
	}

    /**
	 * 删除文件和文件夹
	 *
	 * @method deleteFilesAndFolders
	 * @return {Object}
	 * @example
	 * {
	 * 		goformID : "HTTPSHARE_DEL",
	 * 		path_SD_CARD: params.path,
	 *  	name_SD_CARD: params.names
	 *  }
	 */
    function deleteFilesAndFolders(){
    	return doStuff(arguments, {}, prepare, deal, null, true);

		function prepare(params, isPost) {
			var requestParams = {
				isTest : isTest,
				goformID : "HTTPSHARE_DEL",
				path_SD_CARD : params.path,
				name_SD_CARD : params.names
			};
			return requestParams;
		}

		function deal(data) {
			if (data.result && data.result == "failure") {
				return $.extend(unknownErrorObject, {
					errorType : "delete_folder_failure"
				});
			} else if (data.result && data.result == "no_sdcard") {
				return $.extend(unknownErrorObject, {
					errorType : "no_sdcard"
				});
			} else if (data.result && data.result == "success") {
				return {
					result : true
				};
			} else {
				return unknownErrorObject;
			}
		}
    }

    /**
	 * 创建文件夹
	 *
	 * @method createFolder
	 * @return {Object}
	 * @example
	 * {
	 * 		goformID : "HTTPSHARE_DEL",
	 * 		path_SD_CARD: params.path,
	 *  	name_SD_CARD: params.names
	 *  }
	 */
	function createFolder() {
		return doStuff(arguments, {}, prepare, deal, null, true);

		function prepare(params, isPost) {
            var d = new Date();
            var currentTime = d.getTime();
            var zoneOffsetSeconds = d.getTimezoneOffset() * 60;
			return {
                isTest: isTest,
                goformID: "HTTPSHARE_NEW",
                path_SD_CARD: params.path,
                path_SD_CARD_time: transUnixTime(currentTime),
                path_SD_CARD_time_unix: Math.round((currentTime - zoneOffsetSeconds * 1000) / 1e3)
			};
		}

		function deal(data) {
			if (data.result && data.result == "failure") {
				return $.extend(unknownErrorObject, {
					errorType : "create_folder_failure"
				});
			} else if (data.result && data.result == "no_sdcard") {
				return $.extend(unknownErrorObject, {
					errorType : "no_sdcard"
				});
			} else if (data.result && data.result == "success") {
				return {
					result : true
				};
			} else {
				return unknownErrorObject;
			}
		}
	}

    /**
	 * 检查文件上传状态
	 *
	 * @method checkUploadFileStatus
	 * @return {Object}
	 */
    function checkUploadFileStatus(){
    	return doStuff(arguments, {}, prepare, deal, null, false);

        function prepare(params, isPost) {
            var requestParams = {
	            isTest : isTest,
	            params : "CheckUploadFileStatus"
            };
            return requestParams;
        }

        function deal(data) {
			if (data) {
				if (data.result == "5") {
					return {
						result : false
					};
				} else if (data.result == "6") {
					return {
						result : true
					};
				} else {
					return {
						result : false
					};
				}
			} else {
				return unknownErrorObject;
			}
		}
    }

    /**
	 * 设置SD 卡共享参数
	 *
	 * @method setSdCardSharing
	 * @return {Object}
	 * @example
	 * requestParams = {
	            isTest : isTest,
	            goformID : "HTTPSHARE_AUTH_SET",
        		HTTP_SHARE_STATUS: params.share_status == "1" ? "Enabled" : "Disabled",
        		HTTP_SHARE_WR_AUTH: params.share_auth == "1" ? "readWrite" : "readOnly",
        		HTTP_SHARE_FILE: params.share_file
            };
	 */
    function setSdCardSharing(){
    	return doStuff(arguments, {}, prepare, deal, null, true);

        function prepare(params, isPost) {
            var requestParams = {
	            isTest : isTest,
	            goformID : "HTTPSHARE_AUTH_SET",
        		HTTP_SHARE_STATUS: params.share_status == "1" ? "Enabled" : "Disabled",
        		HTTP_SHARE_WR_AUTH: params.share_auth == "1" ? "readWrite" : "readOnly",
        		HTTP_SHARE_FILE: params.share_file
            };
            return requestParams;
        }

        function deal(data) {
			if (data) {
				if (data.result == "no_sdcard") {
					return $.extend(unknownErrorObject, {
						errorType : "no_sdcard"
					});
				} else {
					return {
						result : true
					};
				}
			} else {
				return unknownErrorObject;
			}
		}
    }

	function getLoginInfo(){
    	return doStuff(arguments, {}, prepare, deal, null, false);

        function prepare(params, isPost) {
            var requestParams = {
	            isTest : isTest,
	            params : "user_logstatus",
	            multi: 1
            };
            return requestParams;
        }

        function deal(data) {
            if (data) {
            	var result = {
        			user_logstatus: data.user_logstatus
            	};
                return result;
            } else {
                return unknownErrorObject;
            }
        }
    }
	return {
		 getSDConfiguration: getSDConfiguration,//Test Done
        setSdCardMode: setSdCardMode,//Test Done
        checkFileExists: checkFileExists,//No Test
        getFileList: getFileList,//Test Done
        fileRename: fileRename,//Test Done
        getSdMemorySizes : getSdMemorySizes,//Test Done
		deleteFilesAndFolders : deleteFilesAndFolders,//Test Done
		createFolder : createFolder,//Test Done
		checkUploadFileStatus : checkUploadFileStatus,//No Test
        setSdCardSharing:setSdCardSharing,
		getLoginInfo:getLoginInfo
    };
}
var service = service();