/**
 * mac filter ģ��
 * @module mac filter
 * @class mac filter
 */

define(['knockout', 'service', 'jquery', 'config/config', 'underscore'],
    function (ko, service, $, config, _) {
		/**
         * macFilterVM
         * @class macFilterVM
         */
		var Modes = _.map(config.WHITE_BLACK_LIST, function(item) {
		return new Option(item.name, item.value);
		});
        function macFilterVM() {
			var info = service.getMacFilterInfo();
            var self = this;
			self.macFilterEnable = ko.observable(info.ACL_mode);
			self.blackListEnabled = ko.observable(info.ACL_mode == "2");
			self.whiteListEnabled = ko.observable(info.ACL_mode == "1");
			self.blackList = ko.observable(parseStringToArray(info.wifi_black_list));
			self.whiteList = ko.observable(parseStringToArray(info.wifi_white_list));
			self.types = ko.observableArray(Modes);
			self.macAddress = ko.observable();
			self.setMacFilter = function() {
			var info = service.getMacFilterInfo();	
			var	macStr = "";
			var mac_str= $("#mac_address").val();
				if (((self.macFilterEnable()=='1') ||(self.macFilterEnable()=='2'))&&(mac_str!=""))
				{
					if(self.checkExist()) 
					{
					
						return;
					}
				}
				
					if(self.macFilterEnable()=='1')
					{

						if(info.wifi_white_list!="")
						{
							if((mac_str!="")&&(mac_str!="undefined"))
							{
								macStr = info.wifi_white_list+';'+mac_str;
							}
							else
							{
								macStr = info.wifi_white_list;
							}
						}
						else
						{
							macStr = mac_str;
						}
					}
					else if(self.macFilterEnable()=='2')
					{

						if(info.wifi_black_list!="")
						{
							if((mac_str!="")&&(mac_str!="undefined"))
							{
								macStr = info.wifi_black_list+';'+mac_str;
							}
							else
							{
								macStr = info.wifi_black_list;
							}
						}
						else
						{
							macStr = self.macAddress();
						}
					}
		
				var requestParams = {
				
					ACL_mode: self.macFilterEnable(),
					wifi_mac_list: macStr
				};
				
				apply(requestParams);
			}
			
			
			removeFromList = function(id){
				var macStr = "";
				var tempArray = "";
				if(self.macFilterEnable()=='1')
				{
					tempArray = self.whiteList();
				}
				else if(self.macFilterEnable()=='2')
				{
					tempArray = self.blackList();
				}
			
				tempArray.splice(parseInt(id, 10), 1);
				_.map(tempArray, function(item){
					macStr = macStr== ''?item.macAddress:macStr+';'+item.macAddress;
				});
				var requestParams = {
					ACL_mode: self.macFilterEnable(),
					wifi_mac_list: macStr
				};
				apply(requestParams);
			}
			
			
			/**
         * ������������Ƿ��Ѿ�����
         * @method checkExist
         */
        self.checkExist = function() {
			var tempArray = "";
            self.macAddress(self.macAddress().toUpperCase());
            var newRule = {
                macAddress: self.macAddress()
            };
			if(self.macFilterEnable()=='1')
			{
				tempArray = self.whiteList();
			}
			else if(self.macFilterEnable()=='2')
			{
				tempArray = self.blackList();
			}
			
			if(tempArray.length>=10)
			{
				showAlert("rule_max_note");
				return true;
			}
            for(var i = 0; i < tempArray.length; i++) {
                if(_.isEqual(self.macAddress(), tempArray[i].macAddress)) {
					showAlert("rule_exist");
                    return true;
                }
            }
            return false;
        }
		
			function apply(params){
				var requestParams = {
					ACL_mode : params.ACL_mode,
					wifi_mac_list : params.wifi_mac_list
				};
				 showAlert("wifi_advanced_note_apply", function(){
				 
						showLoading('in_setting');
						service.setMacFilter(requestParams, function (result) {
						
						self.callback(result);
							
							
						});
						
					});
				
			}
			
		    self.clear = function() {
				self.macAddress('');
				self.blackList([]);
				self.whiteList([]);
				clearValidateMsg();
			};
			  /**
			 * �趨,����,ɾ���ص�����
			 * @method callback
			 */
			self.callback = function(result) {
				if (result.result=== "success") {
					self.clear();
					var info = service.getMacFilterInfo();
					self.macFilterEnable(info.ACL_mode);
					self.blackListEnabled(info.ACL_mode == "2");
					self.whiteListEnabled(info.ACL_mode == "1");
					self.blackList(parseStringToArray(info.wifi_black_list));
					self.whiteList(parseStringToArray(info.wifi_white_list));
					$("#macFilterForm table").translate();
					successOverlay();
				} else {
					errorOverlay();
				}
			};
			
			
		
			function parseStringToArray(strMac) {
				if(strMac == "") {
					return [];
				}
				var tempMac = strMac.split(';');
				var result = [];
				for(var i = 0; i < tempMac.length; i++) {
					var obj = {};
					obj.macAddress = tempMac[i];
					result.push(obj);
				}
				return result;
			}
			
		}

        /**
         * ��ʼ�� ViewModel�������а�
         * @method init
         */
        function init() {
			var container = $("#container");
			ko.cleanNode(container[0]);
			var vm = new macFilterVM();
            ko.applyBindings(vm, container[0]);
			
			$('#macFilterForm').validate({
				submitHandler:function () {
                    vm.setMacFilter();
                },
				rules: {
					mac_address: {
						mac_check: true
					}
				},
				errorPlacement: function(error, element)
				{
					if(element.attr("name") == "mac_address") 
					{
						error.insertAfter("#macExamLabel");
					}
				}
			});
        }

        return {
            init:init
        };
    });
