define(function() {
    var config = {
        IPV6_SUPPORT: true,
        WIFI_BAND_SUPPORT: false,
        WIFI_BANDWIDTH_SUPPORT: false,
        WEBUI_TITLE: '4G MiFi',
        AUTO_MODES: [ {
     name: 'Automatic',
            value: 'NETWORK_auto'
        }, {
            name: '4G Only',
            value: 'Only_LTE'
        }, {
            name: '3G EVDO',
            value: 'Only_EVDO'
        }, {
            name: '2G CDMA',
            value: 'Only_CDMA'
        }],
		AUTO_PREFER: [ {
            name: '4G prefer',
            value: '1'
        }, {
            name: '3G /2G prefer',
            value: '2'
        }],	WHITE_BLACK_LIST: [ {
            name: 'black_white_list_disable',
            value: '0'
        },{
            name: 'white_list_enable',
            value: '1'
        }, {
            name: 'black_list_enable',
            value: '2'
        }]
    };

    return config;
});
