/**
 * 密码管理 模块
 * @module password
 * @class password
 */
define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],

    function ($, ko, config, service, _) {

        /**
         * password ViewModel
         * @class passwordModel
         */
        function mtuModel() {
            var self = this;
			var info = service.getMTUData();
            self.mtu_ipv6 = ko.observable(info.mtu_ipv6);    
		    self.save = function(){
                showAlert("lan_confirm_reopen", function(){
                    self.saveAct();
                });
            };

            self.saveAct = function() {
                showLoading();
                var params = {
                    mtu_ipv6: self.mtu_ipv6(),        
                };
                service.setMTU(params, function(result) {
                    if (result.result == "success") {
                        successOverlay();
                    } else {
                        errorOverlay();
                    }
                });
            };
			
        }

        /**
         * 初始化 ViewModel，并进行绑定
         * @method init
         */
        function init() {
            var vm = new mtuModel();
            ko.applyBindings(vm, $('#container')[0]);

            $('#frmMTU').validate({
                submitHandler:function () {
                   vm.save();
                },
                rules:{
					mtu_ipv6: {
                        digits: true,
                        range: [1280, 65535]
                    }
                }
				
            });

        }

        return {
            init:init
        }
    });
