/**
 * sys log����ģ��
 * @module sysLog
 * @class sysLog
 */
define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],

function($, ko, config, service, _) {
	


	function sysLogViewModel() {
		var self = this;	
		self.logInfomation = ko.observable();	
		showLogInfomation();
		
		
		self.apply = function(){
			service.setSysLog({
				goformID : "SYSLOG",
			}, function(data){
				if(data.result) {
					showLogInfomation();
					successOverlay();
				} else {
					errorOverlay();
				}
			});
		}
		
	

		function showLogInfomation(){
			//addInterval(function(){
				$.ajax({
					url : "weblog",
					cache : false,
					success : function(data) {
						self.logInfomation(data);
					},
					error : function() {
					
					}
				});
			//}, 1000);
		}
		
	}

    /**
     * sys log��ʼ��
     * @method init
     */
	function init() {
		var container = $('#container');
		ko.cleanNode(container[0]);
		var vm = new sysLogViewModel();
		ko.applyBindings(vm, container[0]);
		
		
		$("#sysLogForm").validate({
			submitHandler: function(){
				vm.apply();
			}			
		});
	}
	
	return {
		init: init
	};
});