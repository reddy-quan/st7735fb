/**
 * tr069 configurationģ��
 * @module tr069 config
 * @class tr069 config
 */
define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],

function($, ko, config, service, _) {
	/**
     * tr069 configuration view model
     * @class tr069ConfigViewModel
     */
	function TR069ConfigViewModel() {
		var timer;
		var info = service.getTR069Config();
		/*setInterval(function(){
			var obj = service.getConnectionInfo();
			info.connectStatus = obj.connectStatus;
		}, 1000);*/
		var self = this;
		self.acs_name = ko.observable(info.acs_name);
		self.acs_password = ko.observable(info.acs_password);
		self.period_inform = ko.observable(info.period_inform);
		self.period_inform_interval = ko.observable(info.period_inform_interval);
		self.acs_url = ko.observable(info.acs_url);
		self.acs_cert_enable = ko.observable(info.acs_cert_enable);

		
		self.apply = function() {
			/*if(info.connectStatus != "ppp_connected") {
				showAlert("connect_alert");
				return false;
			}*/
			showAlert("lan_confirm_reopen", function(){
				service.setTR069Configuration({
					goformID: "setTR069Config",
					acs_name: self.acs_name(),
					acs_password: self.acs_password(),
					period_inform: self.period_inform(),
					period_inform_interval: self.period_inform_interval(),
					acs_url: self.acs_url(),
					acs_cert_enable: self.acs_cert_enable()
				}, function(data){
					if(data.result == "success") {
						successOverlay();
						init();
					} else {
						errorOverlay();
					}
				});
			});
		}
		
	}

    /**
     * tr069���ó�ʼ��
     * @method init
     */
	function init() {
		var container = $('#container');
		ko.cleanNode(container[0]);
		var vm = new TR069ConfigViewModel();
		ko.applyBindings(vm, container[0]);
		
		$("#tr069Form").validate({
			submitHandler: function(){
				vm.apply();
			},
			rules: {
				acs_name:"password_check",
				acs_password: "password_check",
				acs_url: "url",
				period_inform_interval: {
                    digits: true,
                    range: [10, 2678400]
                }
			}
		});
	}
	
	return {
		init: init
	};
});